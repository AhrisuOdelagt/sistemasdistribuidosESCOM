/*    --- Información del proyecto ----
	No. de proyecto: Final
	Nombre completo: Franco Olvera Demian Oder
	Grupo: 7CM1
*/

package com.mycompany.app;

public class FrontendSearchRequest {
    private int searchQuery;

    public int getSearchQuery() {
        return searchQuery;
    }
}
